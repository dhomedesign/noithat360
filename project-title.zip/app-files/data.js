var APP_DATA = {
  "scenes": [
    {
      "id": "0-a1",
      "name": "a1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "yaw": 1.3808409379019633,
        "pitch": 0.08015384000568915,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": 1.2437386686903942,
          "pitch": 0.20684222054818946,
          "rotation": 0,
          "target": "1-a2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-a2",
      "name": "a2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "yaw": 1.618707230784464,
        "pitch": 0.14046841893356898,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [
        {
          "yaw": 1.7664987889297112,
          "pitch": 0.1284109491197487,
          "rotation": 0,
          "target": "0-a1"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
